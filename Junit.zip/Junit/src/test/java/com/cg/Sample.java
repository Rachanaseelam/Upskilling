package com.cg;

import org.junit.jupiter.api.Test;

public class Sample {
	
	@Test
	private void test() {
		System.out.println("Not Yest implemented");
	}
}
