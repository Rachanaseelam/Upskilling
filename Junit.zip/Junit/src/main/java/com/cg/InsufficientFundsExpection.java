package com.cg;

public class InsufficientFundsExpection extends Exception {
	private static final long serialVersionUID = 1L;

	public InsufficientFundsExpection() {

	System.out.println("Insufficient Funds");
	}
}
